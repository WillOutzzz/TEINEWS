package com.example.teinews

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.teinews.databinding.FragmentSearchBinding

class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)

        // Simulamos resultados de búsqueda (luego podrías hacerlo dinámico)
        val articles = listOf(
            NewsItem(
                id = 5,
                title = "Cómo mejorar tu PC gamer",
                content = "Guía completa para optimizar tu computadora gaming con los mejores componentes y configuraciones.",
                source = "GamingTech",
                publishTime = "Hace 1 hora",
                category = "Gaming"
            ),
            NewsItem(
                id = 6,
                title = "Los mejores celulares 2025",
                content = "Revisión de los smartphones más destacados que han llegado al mercado este año.",
                source = "PhoneReview",
                publishTime = "Hace 3 horas",
                category = "Smartphones"
            ),
            NewsItem(
                id = 7,
                title = "Tecnología verde: el futuro sostenible",
                content = "Las innovaciones tecnológicas que están ayudando a crear un futuro más sostenible.",
                source = "EcoTech",
                publishTime = "Hace 5 horas",
                category = "Sostenibilidad"
            )
        )

        binding.recyclerViewSearch.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewSearch.adapter = NewsAdapter(articles)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
