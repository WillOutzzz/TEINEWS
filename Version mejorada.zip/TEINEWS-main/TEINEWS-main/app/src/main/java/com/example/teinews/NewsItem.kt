package com.example.teinews

import java.io.Serializable

data class NewsItem(
    val id: Int,
    val title: String,
    val content: String,
    val source: String,
    val publishTime: String,
    val category: String,
    val isFavorite: Boolean = false,
    val isSaved: Boolean = false,
    val isReadLater: Boolean = false
) : Serializable
