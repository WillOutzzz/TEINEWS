package com.example.teinews

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.teinews.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        val articles = listOf(
            NewsItem(
                id = 1,
                title = "Nuevos chips Intel 2025",
                content = "Intel ha anunciado su nueva generación de procesadores que prometen un rendimiento superior y mayor eficiencia energética.",
                source = "TechNews",
                publishTime = "Hace 2 horas",
                category = "Tecnología"
            ),
            NewsItem(
                id = 2,
                title = "Avances en inteligencia artificial",
                content = "Los últimos desarrollos en IA están revolucionando múltiples industrias con aplicaciones innovadoras.",
                source = "AI Weekly",
                publishTime = "Hace 4 horas",
                category = "Inteligencia Artificial"
            ),
            NewsItem(
                id = 3,
                title = "La revolución del 5G",
                content = "La tecnología 5G está transformando la conectividad móvil con velocidades sin precedentes.",
                source = "MobileTech",
                publishTime = "Hace 6 horas",
                category = "Telecomunicaciones"
            ),
            NewsItem(
                id = 4,
                title = "Gadgets más esperados del año",
                content = "Una mirada a los dispositivos tecnológicos más prometedores que llegarán este año.",
                source = "GadgetReview",
                publishTime = "Hace 8 horas",
                category = "Gadgets"
            )
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = NewsAdapter(articles)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
