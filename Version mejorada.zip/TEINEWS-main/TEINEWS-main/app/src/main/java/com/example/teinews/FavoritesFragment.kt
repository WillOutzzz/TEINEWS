package com.example.teinews

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.teinews.databinding.FragmentFavoritesBinding

class FavoritesFragment : Fragment() {

    private var _binding: FragmentFavoritesBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFavoritesBinding.inflate(inflater, container, false)

        val favorites = listOf(
            NewsItem(
                id = 8,
                title = "Intel anuncia nueva generación de procesadores",
                content = "La compañía presenta sus últimos avances en tecnología de procesadores con mejoras significativas.",
                source = "TechNews",
                publishTime = "Hace 1 día",
                category = "Tecnología",
                isFavorite = true
            ),
            NewsItem(
                id = 9,
                title = "Top 10 innovaciones tecnológicas del año",
                content = "Un repaso a las tecnologías más impactantes que han marcado este año.",
                source = "Innovation Weekly",
                publishTime = "Hace 2 días",
                category = "Innovación",
                isFavorite = true
            )
        )

        binding.recyclerViewFavorites.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewFavorites.adapter = NewsAdapter(favorites)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
